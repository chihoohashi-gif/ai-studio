//go:build !updateable

package ghcmd

// See update_enabled.go comment for more information.
var updaterEnabled = ""
